import Snackbar from './Snackbar'

export default Snackbar
