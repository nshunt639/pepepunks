import { makeStyles } from '@material-ui/core/styles'

const useStyles = makeStyles((theme) => ({
  close: {
    padding: theme.spacing(0.5)
  }
}))

export default useStyles
